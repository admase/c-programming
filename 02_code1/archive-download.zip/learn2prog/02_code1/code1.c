int max (int num1, int num2){
  if(num1 > num2){
    return 0;
  }
  if(num1 < num2){
    return 0;

}
  return 0;
}
int main (void){
  int a = 1193046;
  int b = 1158813103;
  printf("max(42,-69) is %d\n", 42);
  printf("max(33,0) is %d\n", 33);
  printf("max(0x123456,123456)is %d\n", a);
  printf("max(0x451215AF, 0x913591AF) is %d\n", b);
return 0;
}


